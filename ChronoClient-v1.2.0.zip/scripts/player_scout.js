"use strict";
(() => {
  // src/entity_fields.ts
  var ENTITY_FIELDS = [
    {
      "label": "optional",
      "name": "id",
      "number": 1,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "entity_type",
      "number": 2,
      "type": "enum",
      "type_name": "EntityType"
    },
    {
      "label": "optional",
      "name": "removed",
      "number": 3,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "x",
      "number": 4,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "y",
      "number": 5,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "radius",
      "number": 6,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "width",
      "number": 7,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "height",
      "number": 8,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "duration",
      "number": 9,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "distance_travelled",
      "number": 10,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "strength",
      "number": 11,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "orb_type",
      "number": 12,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "name",
      "number": 13,
      "type": "string",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "alpha",
      "number": 14,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "speed",
      "number": 15,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "level",
      "number": 16,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "experience",
      "number": 17,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "previous_level_experience",
      "number": 18,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "next_level_experience",
      "number": 19,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "upgrade_points",
      "number": 20,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "energy",
      "number": 21,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "max_energy",
      "number": 22,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "energy_regen",
      "number": 23,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "death_timer",
      "number": 24,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "death_timer_total",
      "number": 25,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "hero_type",
      "number": 26,
      "type": "enum",
      "type_name": "HeroType"
    },
    {
      "label": "optional",
      "name": "ability_one",
      "number": 27,
      "type": "message",
      "type_name": "Ability"
    },
    {
      "label": "optional",
      "name": "ability_two",
      "number": 28,
      "type": "message",
      "type_name": "Ability"
    },
    {
      "label": "optional",
      "name": "ability_three",
      "number": 29,
      "type": "message",
      "type_name": "Ability"
    },
    {
      "label": "optional",
      "name": "night_activated",
      "number": 30,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "repeated",
      "name": "effects",
      "number": 31,
      "type": "message",
      "type_name": "Effect"
    },
    {
      "label": "optional",
      "name": "is_harmless",
      "number": 32,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "region_highest_area_achieved",
      "number": 33,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "win_count",
      "number": 34,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "rescued_count",
      "number": 35,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "survival_time",
      "number": 36,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "active_time",
      "number": 37,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "trial_time",
      "number": 38,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "hat_name",
      "number": 39,
      "type": "string",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "body_name",
      "number": 40,
      "type": "string",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "gem_name",
      "number": 41,
      "type": "string",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_iced",
      "number": 42,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "iced_time",
      "number": 43,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "iced_time_left",
      "number": 44,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_snowballed",
      "number": 45,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "snowballed_time",
      "number": 46,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "snowballed_time_left",
      "number": 47,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_departed",
      "number": 48,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_bandaged",
      "number": 49,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_unbandaging",
      "number": 50,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "fusion_activated",
      "number": 51,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "mortar_time",
      "number": 52,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "in_fear",
      "number": 53,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "area_number",
      "number": 54,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "area_name",
      "number": 55,
      "type": "string",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "region_name",
      "number": 56,
      "type": "string",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "boss_area",
      "number": 57,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "victory_area",
      "number": 58,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "rescueable",
      "number": 59,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "decayed",
      "number": 60,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "shatter_time",
      "number": 61,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "sugar_rush_activated",
      "number": 62,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "sweet_tooth_consumed",
      "number": 63,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_obscured",
      "number": 64,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_poisoned",
      "number": 65,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "poisoned_time",
      "number": 66,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "poisoned_time_left",
      "number": 67,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "crumbled_invulnerability",
      "number": 68,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "crumbled_time_left",
      "number": 69,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "shaken",
      "number": 70,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "shaken_immune",
      "number": 71,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "healing_time",
      "number": 72,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_sticky_coat_activated",
      "number": 73,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "can_cling",
      "number": 74,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "burning",
      "number": 75,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "shadowed_invulnerability",
      "number": 76,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "shadowed_time",
      "number": 77,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "shadowed_time_left",
      "number": 78,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_wormhole",
      "number": 79,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_destroyed",
      "number": 80,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "grass_time",
      "number": 81,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "grass_harmless",
      "number": 82,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "sticky_coat_disabled",
      "number": 83,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "brightness",
      "number": 84,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "electrify_interval",
      "number": 85,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_stone",
      "number": 86,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "gained_immunity",
      "number": 87,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "robo_scanner_id",
      "number": 88,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "energized",
      "number": 89,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "has_wind_debuff",
      "number": 90,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "has_water_debuff",
      "number": 91,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "has_fire_debuff",
      "number": 92,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "has_earth_debuff",
      "number": 93,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "cybot_defeated",
      "number": 94,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "reduced",
      "number": 95,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_repelling",
      "number": 96,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "image_name",
      "number": 97,
      "type": "string",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "color_change",
      "number": 98,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "health",
      "number": 99,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "max_health",
      "number": 100,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "texture",
      "number": 101,
      "type": "enum",
      "type_name": "TextureType"
    },
    {
      "label": "optional",
      "name": "player_interactions",
      "number": 102,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "visual_radius",
      "number": 103,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "under_libot_effect",
      "number": 104,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "under_dabot_effect",
      "number": 105,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "provoked",
      "number": 106,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "lead_time",
      "number": 107,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "petrified",
      "number": 108,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "ictos_invulnerability",
      "number": 109,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "continuous_revive",
      "number": 110,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "continuous_revive_time",
      "number": 111,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "continuous_revive_time_left",
      "number": 112,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "release_time",
      "number": 113,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "stored_pellets",
      "number": 114,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "mutatiorb_buff_speed_boost",
      "number": 115,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "mutatiorb_buff_cooldown_reduction",
      "number": 116,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "mutatiorb_buff_effects_reduction",
      "number": 117,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "mutatiorb_buff_slower_death_timer",
      "number": 118,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "mutatiorb_buff_experience_gain",
      "number": 119,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "has_radioactive_gloop",
      "number": 120,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "mutatiorb_buff_front_shield",
      "number": 121,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "shield_angle",
      "number": 122,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "mutatiorb_buffed",
      "number": 123,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_clinging",
      "number": 124,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "inactive",
      "number": 125,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "dashes",
      "number": 126,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "sour_candy_consumed",
      "number": 127,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "ability_removed",
      "number": 128,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "has_undead_infection",
      "number": 129,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "harmless_time",
      "number": 130,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "flaming_time_left",
      "number": 131,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "can_gain_energy",
      "number": 132,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "growing_time_left",
      "number": 133,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "growing_time_total",
      "number": 134,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_ember_invulnerable",
      "number": 135,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "switch_time",
      "number": 136,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "switched_harmless",
      "number": 137,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "fading",
      "number": 138,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "fade_in_time",
      "number": 139,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "parry_activated",
      "number": 140,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "parried",
      "number": 141,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "slash_break",
      "number": 142,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "network_control_time",
      "number": 143,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_burning",
      "number": 144,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_burning_time",
      "number": 145,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_umbreled",
      "number": 146,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "umbreled_time",
      "number": 147,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "hidden",
      "number": 148,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "lotus_brightness",
      "number": 149,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "star_visibility",
      "number": 150,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "on_wall",
      "number": 151,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "slashing",
      "number": 152,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "slash_time",
      "number": 153,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "grass_fade_time",
      "number": 154,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "fade_out_time",
      "number": 155,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "frozen_time",
      "number": 156,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "frozen_time_left",
      "number": 157,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "poison_time",
      "number": 158,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "poison_time_left",
      "number": 159,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "lava_time",
      "number": 160,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "lava_time_left",
      "number": 161,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "sugar_rush_time",
      "number": 162,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "sugar_rush_time_left",
      "number": 163,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "stomped_stun_time",
      "number": 164,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "vengeance_time",
      "number": 165,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "vengeance_time_left",
      "number": 166,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "vengeance_frozen",
      "number": 167,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "spark_time",
      "number": 168,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "spark_time_left",
      "number": 169,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "lightning_time",
      "number": 170,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "lightning_time_left",
      "number": 171,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "total_speed",
      "number": 172,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "total_energy_regen",
      "number": 173,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "in_stream_path",
      "number": 174,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_invulnerable",
      "number": 175,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "ability_helper_time",
      "number": 176,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "ability_helper_type",
      "number": 177,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "explodiorb_time",
      "number": 178,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "depart_time_left",
      "number": 179,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "powered",
      "number": 180,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "powered_time",
      "number": 181,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "powered_time_interval",
      "number": 182,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "voidborne_invulnerable",
      "number": 183,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "voidborne_invulnerable_time",
      "number": 184,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "voidborne_invulnerable_time_left",
      "number": 185,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "void_drain_time_left",
      "number": 186,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "orbiting_duration",
      "number": 187,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "void_time",
      "number": 188,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "lava_gaining_energy",
      "number": 189,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "undead_infection_revived_time",
      "number": 190,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "ignore_revival_abilities",
      "number": 191,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_freezing",
      "number": 192,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "slash_targeted_time",
      "number": 193,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "slash_targeted_time_left",
      "number": 194,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "broken_resistance_multiplier",
      "number": 195,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "particle_style",
      "number": 196,
      "type": "enum",
      "type_name": "ParticleStyle"
    },
    {
      "label": "optional",
      "name": "square",
      "number": 197,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "no_outlines",
      "number": 198,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "crystal",
      "number": 199,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "ghost",
      "number": 200,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_ghost_copy",
      "number": 201,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "beam_segment_count",
      "number": 202,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "beam_thickness",
      "number": 203,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "beam_life_time_left",
      "number": 204,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "beam_life_time_total",
      "number": 205,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "beam_seed",
      "number": 206,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "beam_harmful_time_left",
      "number": 207,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "beam_harmful_delay",
      "number": 208,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "beam_harmful_fade_time_left",
      "number": 209,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "beam_harmful_fade_time_total",
      "number": 210,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "crystal_wall_count",
      "number": 211,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "crystal_wall_growth_total",
      "number": 212,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "crystal_wall_growth_left",
      "number": 213,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "crystal_wall_growth_duration",
      "number": 214,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "crystal_wall_harmful_delay",
      "number": 215,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "crystal_wall_harmful_fade_time",
      "number": 216,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "crystal_wall_seed",
      "number": 217,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "repeated",
      "name": "beam_points",
      "number": 218,
      "type": "float",
      "type_name": null
    },
    {
      "label": "repeated",
      "name": "crystal_wall_nodes",
      "number": 219,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "beam_homing",
      "number": 220,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "homing",
      "number": 221,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "velocity_x",
      "number": 222,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "velocity_y",
      "number": 223,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "effects_multiplier",
      "number": 224,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "sweet_tooth_stat_boost",
      "number": 225,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "sweet_tooth_consumed_time",
      "number": 226,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "sour_candy_stat_reduction",
      "number": 227,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "sour_candy_consumed_time",
      "number": 228,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "stream_path_speed_boost",
      "number": 229,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "sticky_coat_total_players",
      "number": 230,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_bandaging",
      "number": 231,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "bandaging_time_left",
      "number": 232,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "night_time",
      "number": 233,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "earthquake_time",
      "number": 234,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "time_preparing",
      "number": 235,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "time_dashing",
      "number": 236,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "time_since_last_dash",
      "number": 237,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "dash_speed",
      "number": 238,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "lunge_timer",
      "number": 239,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "time_during_lunge",
      "number": 240,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "lunge_cooldown_timer",
      "number": 241,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "lunge_speed",
      "number": 242,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "sizing_multiplier",
      "number": 243,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "growing",
      "number": 244,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "wall_hit",
      "number": 245,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "wall_time_left",
      "number": 246,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "snowman_radius_multiplier",
      "number": 247,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "pause_time",
      "number": 248,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "pause_interval",
      "number": 249,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "teleport_distance",
      "number": 250,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "is_orbiting",
      "number": 251,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "orbiting_time_left",
      "number": 252,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "pumpkin_activation_timer",
      "number": 253,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "pumpkin_activated",
      "number": 254,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "movement_time",
      "number": 255,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "has_pollinated",
      "number": 256,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "pollinate_control_type",
      "number": 257,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "source_entity_id",
      "number": 258,
      "type": "int32",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "player_detection_radius",
      "number": 259,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "activated",
      "number": 260,
      "type": "bool",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "home_range",
      "number": 261,
      "type": "float",
      "type_name": null
    },
    {
      "label": "optional",
      "name": "increment",
      "number": 262,
      "type": "float",
      "type_name": null
    }
  ];

  // src/codec.ts
  var lg = new TextDecoder("utf-8");
  var sg = new TextEncoder();
  var fg = (e) => e.replace(/[A-Z]/g, (c) => `_${c.toLowerCase()}`);
  var SCHEMAS = {
    Entity: {
      name: "Entity",
      fields: ENTITY_FIELDS
    },
    ClientPayload: {
      name: "ClientPayload",
      fields: [
        { label: "optional", name: "hero_selection", number: 1, type: "enum" },
        { label: "optional", name: "sequence", number: 2, type: "int32" },
        { label: "repeated", name: "keys", number: 3, type: "message", type_name: "Key" },
        { label: "optional", name: "mouse_down", number: 4, type: "message", type_name: "MouseDown" },
        { label: "optional", name: "message", number: 5, type: "string" },
        { label: "optional", name: "settings", number: 6, type: "message", type_name: "Settings" },
        { label: "repeated", name: "blocked_usernames", number: 7, type: "string" },
        { label: "repeated", name: "unblocked_usernames", number: 8, type: "string" },
        { label: "optional", name: "ping", number: 11, type: "int32" }
      ]
    },
    ConnectionPayload: {
      name: "ConnectionPayload",
      fields: [
        { label: "optional", name: "connection_type", number: 1, type: "enum" },
        { label: "optional", name: "username", number: 2, type: "string" },
        { label: "optional", name: "settings", number: 3, type: "message", type_name: "Settings" },
        { label: "optional", name: "quest_data", number: 4, type: "message", type_name: "QuestData" },
        { label: "optional", name: "error", number: 5, type: "string" }
      ]
    },
    Area: {
      name: "Area",
      fields: [
        { label: "optional", name: "index", number: 1, type: "int32" },
        { label: "optional", name: "number", number: 2, type: "int32" },
        { label: "optional", name: "name", number: 3, type: "string" },
        { label: "optional", name: "x", number: 4, type: "int32" },
        { label: "optional", name: "y", number: 5, type: "int32" },
        { label: "optional", name: "width", number: 6, type: "int32" },
        { label: "optional", name: "height", number: 7, type: "int32" },
        { label: "repeated", name: "zones", number: 8, type: "message", type_name: "Zone" },
        { label: "optional", name: "region_name", number: 9, type: "string" },
        { label: "optional", name: "boss_area", number: 10, type: "bool" },
        { label: "optional", name: "victory_area", number: 11, type: "bool" },
        { label: "optional", name: "lighting", number: 12, type: "float" },
        { label: "optional", name: "snow", number: 13, type: "float" },
        { label: "optional", name: "sakura_leaves", number: 14, type: "float" }
      ]
    },
    Zone: {
      name: "Zone",
      fields: [
        { label: "optional", name: "x", number: 1, type: "int32" },
        { label: "optional", name: "y", number: 2, type: "int32" },
        { label: "optional", name: "width", number: 3, type: "int32" },
        { label: "optional", name: "height", number: 4, type: "int32" },
        { label: "optional", name: "type", number: 5, type: "enum" },
        { label: "optional", name: "background_color", number: 6, type: "uint32" },
        { label: "optional", name: "texture", number: 7, type: "enum" },
        { label: "optional", name: "friction", number: 8, type: "float" },
        { label: "optional", name: "minimum_speed", number: 9, type: "float" },
        { label: "optional", name: "maximum_speed", number: 10, type: "float" }
      ]
    },
    GlobalEntity: {
      name: "GlobalEntity",
      fields: [
        { label: "optional", name: "id", number: 1, type: "int32" },
        { label: "optional", name: "name", number: 2, type: "string" },
        { label: "optional", name: "area_name", number: 3, type: "string" },
        { label: "optional", name: "area_number", number: 4, type: "int32" },
        { label: "optional", name: "hero", number: 5, type: "enum" },
        { label: "optional", name: "level", number: 6, type: "int32" },
        { label: "optional", name: "color", number: 7, type: "uint32" },
        { label: "optional", name: "alive", number: 8, type: "bool" }
      ]
    }
  };
  var dg = (schema) => {
    const byNumber = /* @__PURE__ */ new Map();
    const byName = /* @__PURE__ */ new Map();
    for (const a of schema.fields || []) {
      const camelName = a.name.replace(/_([a-z])/g, (_, t) => t.toUpperCase());
      byNumber.set(a.number, { ...a, camelName });
      byName.set(a.name, a);
    }
    return { byNumber, byName };
  };
  var hg = new Map(
    Object.entries(SCHEMAS).map(([k, v]) => [k, { ...v, fieldMap: dg(v) }])
  );
  var BinaryWriter = class {
    bytes = [];
    writeUint8(e) {
      this.bytes.push(255 & e);
    }
    writeUint16(e) {
      this.bytes.push(255 & e, e >> 8 & 255);
    }
    writeUint32(e) {
      this.bytes.push(255 & e, e >> 8 & 255, e >> 16 & 255, e >> 24 & 255);
    }
    writeInt32(e) {
      this.writeUint32(e >>> 0);
    }
    writeFloat32(e) {
      const t = new ArrayBuffer(4);
      new DataView(t).setFloat32(0, e, true);
      const r = new Uint8Array(t);
      this.bytes.push(r[0], r[1], r[2], r[3]);
    }
    writeBytes(e) {
      this.writeUint32(e.length);
      for (let i = 0; i < e.length; i++) {
        this.bytes.push(e[i]);
      }
    }
    toUint8Array() {
      return new Uint8Array(this.bytes);
    }
  };
  var BinaryReader = class {
    view;
    buffer;
    offset = 0;
    constructor(buffer) {
      if (buffer instanceof Uint8Array) {
        this.buffer = buffer;
        this.view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
      } else {
        this.buffer = new Uint8Array(buffer);
        this.view = new DataView(buffer);
      }
    }
    hasMore() {
      return this.offset < this.buffer.length;
    }
    readUint8() {
      if (this.offset >= this.buffer.length) return 0;
      const v = this.view.getUint8(this.offset);
      this.offset += 1;
      return v;
    }
    readUint16() {
      if (this.offset + 2 > this.buffer.length) return 0;
      const v = this.view.getUint16(this.offset, true);
      this.offset += 2;
      return v;
    }
    readUint32() {
      if (this.offset + 4 > this.buffer.length) return 0;
      const v = this.view.getUint32(this.offset, true);
      this.offset += 4;
      return v;
    }
    readInt32() {
      if (this.offset + 4 > this.buffer.length) return 0;
      const v = this.view.getInt32(this.offset, true);
      this.offset += 4;
      return v;
    }
    readFloat32() {
      if (this.offset + 4 > this.buffer.length) return 0;
      const v = this.view.getFloat32(this.offset, true);
      this.offset += 4;
      return v;
    }
    readBytes() {
      const len = this.readUint32();
      if (len <= 0 || this.offset + len > this.buffer.length) return new Uint8Array(0);
      const start = this.offset;
      const end = start + len;
      this.offset = end;
      return this.buffer.subarray(start, end);
    }
  };
  var ug = (e) => {
    const t = hg.get(e);
    if (!t) throw new Error(`Unknown schema: ${e}`);
    return t;
  };
  var gg = (writer, field, val) => {
    switch (field.type) {
      case "int32":
      case "sint32":
      case "sfixed32":
      case "enum":
        writer.writeInt32(val);
        break;
      case "uint32":
      case "fixed32":
        writer.writeUint32(val);
        break;
      case "float":
        writer.writeFloat32(val);
        break;
      case "bool":
        writer.writeUint8(val ? 1 : 0);
        break;
      case "string":
        writer.writeBytes(sg.encode(val));
        break;
      case "bytes":
        writer.writeBytes(val instanceof ArrayBuffer ? new Uint8Array(val) : val);
        break;
      case "message": {
        const schema = ug(field.type_name);
        pg(writer, schema, val);
        break;
      }
      default:
        throw new Error(`Unsupported field type: ${field.type}`);
    }
  };
  var pg = (writer, schema, obj) => {
    const list = [];
    for (const [k, v] of Object.entries(obj)) {
      if (v == null) continue;
      const snk = fg(k);
      const fld = schema.fieldMap.byName.get(snk);
      if (fld) list.push([fld, v]);
    }
    list.sort((a, b) => a[0].number - b[0].number);
    writer.writeUint16(list.length);
    for (const [fld, val] of list) {
      writer.writeUint16(fld.number);
      if (fld.label === "repeated" && Array.isArray(val)) {
        writer.writeUint16(val.length);
        for (const item of val) {
          gg(writer, fld, item);
        }
      } else {
        gg(writer, fld, val);
      }
    }
  };
  var encodePayload = (schemaName, payload) => {
    const schema = ug(schemaName);
    const writer = new BinaryWriter();
    pg(writer, schema, payload);
    return writer.toUint8Array();
  };
  var yg = (reader, field) => {
    switch (field.type) {
      case "int32":
      case "sint32":
      case "sfixed32":
      case "enum":
        return reader.readInt32();
      case "uint32":
      case "fixed32":
        return reader.readUint32();
      case "float":
        return reader.readFloat32();
      case "bool":
        return 1 === reader.readUint8();
      case "string":
        return lg.decode(reader.readBytes());
      case "bytes":
        return reader.readBytes();
      case "message": {
        if (field.type_name === "Zone") return xg(reader, ug("Zone"));
        if (field.type_name === "Area") return xg(reader, ug("Area"));
        if (field.type_name === "GlobalEntity") return xg(reader, ug("GlobalEntity"));
        return null;
      }
      default:
        return reader.readFloat32();
    }
  };
  var xg = (reader, schema) => {
    const count = reader.readUint16();
    const result = {};
    for (let a = 0; a < count; a++) {
      const num = reader.readUint16();
      const fld = schema.fieldMap.byNumber.get(num);
      if (!fld) {
        reader.readFloat32();
        continue;
      }
      const name = fld.camelName;
      if (fld.label === "repeated") {
        const arrLen = reader.readUint16();
        const arr = [];
        for (let i = 0; i < arrLen; i++) {
          arr.push(yg(reader, fld));
        }
        result[name] = arr;
      } else {
        result[name] = yg(reader, fld);
      }
    }
    return result;
  };
  var decodeMessage = (schemaName, buffer) => {
    const schema = ug(schemaName);
    const reader = new BinaryReader(buffer);
    return xg(reader, schema);
  };
  var Tg = dg(SCHEMAS.Entity);
  var decodeFramePayload = (buffer) => {
    const reader = new BinaryReader(buffer);
    const version = reader.readUint8();
    if (4 !== version) return null;
    const i = reader.readUint8();
    const a = reader.readUint8();
    const n = reader.readUint8();
    const obj = {
      sequence: reader.readUint32(),
      entities: [],
      globalEntities: [],
      debugObjects: []
    };
    if (1 & i) obj.complete = true;
    if (2 & i) obj.completeGlobal = true;
    if (4 & i) obj.reset = true;
    if (8 & i) obj.selfId = reader.readUint32();
    if (16 & i) obj.tickRate = reader.readFloat32();
    if (32 & i) obj.pong = reader.readUint32();
    if (64 & i) obj.area = decodeMessage("Area", reader.readBytes());
    if (128 & i) obj.map = reader.readBytes();
    if (1 & a) obj.chat = reader.readBytes();
    if (2 & a) obj.settings = reader.readBytes();
    if (4 & a) obj.modToolsResponse = reader.readBytes();
    if (8 & a) obj.questData = reader.readBytes();
    if (16 & a) obj.xEntities = reader.readBytes();
    if (32 & a) obj.yEntities = reader.readBytes();
    if (64 & a) obj.xyEntities = reader.readBytes();
    if (128 & a) obj.xyRadiusEntities = reader.readBytes();
    if (1 & n) obj.spectating = true;
    if (2 & n) obj.serverTime = reader.readUint32();
    const entCount = reader.readUint32();
    for (let e = 0; e < entCount && reader.hasMore(); e++) {
      obj.entities.push(xg(reader, { fieldMap: Tg }));
    }
    const globalCount = reader.readUint32();
    const globalSchema = ug("GlobalEntity");
    for (let e = 0; e < globalCount && reader.hasMore(); e++) {
      obj.globalEntities.push(xg(reader, globalSchema));
    }
    return obj;
  };

  // src/index.ts
  var PlayerScoutMod = class {
    isVisible = false;
    rootElement = null;
    launcherBtn = null;
    serversData = [];
    isFetching = false;
    searchQuery = "";
    selectedPlayer = null;
    selectedPlayerProfile = null;
    selectedPlayerServer = null;
    // Live Stream & Canvas Reconstruction State
    specSocket = null;
    specPingInterval = null;
    isConnectionHandshakeDone = false;
    specCanvas = null;
    specAnimFrameId = null;
    specStatus = "Standby";
    specArea = null;
    specEntities = [];
    specGlobalEntities = [];
    specCamPos = { x: 0, y: 0 };
    lastFrameTime = 0;
    fpsCount = 60;
    constructor() {
      this.initUI();
      this.mountUI();
      this.bindEvents();
      this.refreshServerList();
    }
    // ------------------------------------------------------------------------
    // API HELPERS
    // ------------------------------------------------------------------------
    async fetchGameList() {
      try {
        const res = await fetch("/api/game/list", { credentials: "same-origin" });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        const results = [];
        const regions = ["NA", "EU"];
        for (const reg of regions) {
          const regServers = data.servers[reg];
          if (!regServers) continue;
          for (const key of Object.keys(regServers)) {
            const idx = parseInt(key, 10);
            const s = regServers[key];
            results.push({
              region: reg,
              serverNumber: idx + 1,
              backendIndex: idx,
              gameIndex: 0,
              connected: s.connected || 0,
              capacity: s.capacity || 100,
              online: Array.isArray(s.online) ? s.online : [],
              host: s.host
            });
          }
        }
        this.serversData = results;
        return results;
      } catch {
        return [];
      }
    }
    async fetchPlayerProfile(username) {
      try {
        const res = await fetch(`/api/account/${encodeURIComponent(username)}`, { credentials: "same-origin" });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const profile = await res.json();
        return profile;
      } catch {
        return null;
      }
    }
    nameToHost(region) {
      const hostname = location.hostname.replace("eu.", "");
      if (hostname === "localhost") return "localhost";
      return region === "EU" ? hostname.replace("evades", "eu.evades") : hostname;
    }
    uint32ToColor(c) {
      if (!c) return "#ff4444";
      const hex = (c >>> 0).toString(16).padStart(6, "0");
      return `#${hex.slice(-6)}`;
    }
    // ------------------------------------------------------------------------
    // SPECTATOR SOCKET & REAL-TIME BINARY STREAM
    // ------------------------------------------------------------------------
    startSpectatorStream(username, server) {
      this.stopSpectatorStream();
      this.selectedPlayer = username;
      this.selectedPlayerServer = server;
      this.specCamPos = { x: 1e3, y: 1e3 };
      this.specEntities = [];
      this.specArea = null;
      this.isConnectionHandshakeDone = false;
      try {
        const isHttps = location.protocol === "https:";
        const wsProto = isHttps ? "wss://" : "ws://";
        const host = server.host || this.nameToHost(server.region);
        const port = location.port ? `:${location.port}` : "";
        const wsUrl = `${wsProto}${host}${port}/api/game/connect?backend=${server.backendIndex}&game=${server.gameIndex}`;
        this.specStatus = `Connecting to ${server.region} ${server.serverNumber}...`;
        this.renderSpectateUI();
        this.specSocket = new WebSocket(wsUrl);
        this.specSocket.binaryType = "arraybuffer";
        this.specSocket.onopen = () => {
          this.specStatus = `\u{1F7E2} Connected \u2022 Synchronizing stream (${server.region} ${server.serverNumber})`;
          this.renderSpectateStatus();
          this.specPingInterval = setInterval(() => {
            if (this.specSocket && this.specSocket.readyState === WebSocket.OPEN) {
              const pingBuf = encodePayload("ClientPayload", {
                sequence: 0,
                ping: Math.round(performance.now())
              });
              this.specSocket.send(pingBuf.buffer);
            }
          }, 1e3);
        };
        this.specSocket.onmessage = (event) => {
          if (event.data instanceof ArrayBuffer) {
            this.handleIncomingPacket(event.data);
          }
        };
        this.specSocket.onclose = () => {
          this.specStatus = "Stream Disconnected";
          this.renderSpectateStatus();
          this.stopSpectatorStream();
        };
        this.specSocket.onerror = () => {
          this.specStatus = "Connection Error";
          this.renderSpectateStatus();
        };
        this.startCanvasRenderLoop();
      } catch {
        this.specStatus = "Failed to launch stream";
        this.renderSpectateStatus();
      }
    }
    stopSpectatorStream() {
      if (this.specPingInterval) {
        clearInterval(this.specPingInterval);
        this.specPingInterval = null;
      }
      if (this.specSocket) {
        try {
          this.specSocket.close();
        } catch {
        }
        this.specSocket = null;
      }
      if (this.specAnimFrameId) {
        cancelAnimationFrame(this.specAnimFrameId);
        this.specAnimFrameId = null;
      }
    }
    handleIncomingPacket(buffer) {
      try {
        if (!this.isConnectionHandshakeDone) {
          const conn = decodeMessage("ConnectionPayload", buffer);
          this.isConnectionHandshakeDone = true;
          if (conn && conn.error) {
            this.specStatus = `Error: ${conn.error}`;
            this.renderSpectateStatus();
            return;
          }
          this.specStatus = `\u{1F534} LIVE STREAMING (${this.selectedPlayerServer?.region} ${this.selectedPlayerServer?.serverNumber})`;
          this.renderSpectateStatus();
          if (this.selectedPlayer && this.specSocket && this.specSocket.readyState === WebSocket.OPEN) {
            const spectateMsg = encodePayload("ClientPayload", {
              sequence: 0,
              message: `/spectate "${this.selectedPlayer.replaceAll('"', '\\"')}"`
            });
            this.specSocket.send(spectateMsg.buffer);
          }
          return;
        }
        const frame = decodeFramePayload(buffer);
        if (frame) {
          if (frame.area) {
            this.specArea = frame.area;
          }
          if (Array.isArray(frame.entities)) {
            this.specEntities = frame.entities;
          }
          if (Array.isArray(frame.globalEntities)) {
            this.specGlobalEntities = frame.globalEntities;
          }
        }
      } catch {
      }
    }
    // ------------------------------------------------------------------------
    // CANVAS RECONSTRUCTION RENDERER (Goatunn-Style Arena Reconstruction)
    // ------------------------------------------------------------------------
    startCanvasRenderLoop() {
      const render = () => {
        this.renderReconstructedCanvas();
        this.specAnimFrameId = requestAnimationFrame(render);
      };
      if (!this.specAnimFrameId) {
        this.specAnimFrameId = requestAnimationFrame(render);
      }
    }
    renderReconstructedCanvas() {
      const cvs = this.specCanvas;
      if (!cvs) return;
      const ctx = cvs.getContext("2d");
      if (!ctx) return;
      const vw = cvs.clientWidth || 400;
      const vh = cvs.clientHeight || 300;
      if (cvs.width !== vw || cvs.height !== vh) {
        cvs.width = vw;
        cvs.height = vh;
      }
      ctx.fillStyle = "#030c0a";
      ctx.fillRect(0, 0, vw, vh);
      const area = this.specArea || { x: 0, y: 0, width: 2e3, height: 2e3, name: "Scanning Area...", number: 1, zones: [] };
      let targetX = (area.width || 2e3) / 2;
      let targetY = (area.height || 2e3) / 2;
      if (this.specEntities.length > 0) {
        const heroEnt = this.specEntities.find((e) => e.radius >= 14 && e.radius <= 18) || this.specEntities[0];
        if (heroEnt && typeof heroEnt.x === "number" && typeof heroEnt.y === "number") {
          targetX = heroEnt.x;
          targetY = heroEnt.y;
        }
      }
      this.specCamPos.x += (targetX - this.specCamPos.x) * 0.15;
      this.specCamPos.y += (targetY - this.specCamPos.y) * 0.15;
      const scale = Math.min(vw / 1280, vh / 720) * 1.05;
      const cx = vw / 2 - this.specCamPos.x * scale;
      const cy = vh / 2 - this.specCamPos.y * scale;
      ctx.save();
      ctx.translate(cx, cy);
      ctx.scale(scale, scale);
      ctx.fillStyle = "#071c17";
      ctx.fillRect(0, 0, area.width || 2e3, area.height || 2e3);
      ctx.strokeStyle = "rgba(16, 185, 129, 0.4)";
      ctx.lineWidth = 4 / scale;
      ctx.strokeRect(0, 0, area.width || 2e3, area.height || 2e3);
      ctx.strokeStyle = "rgba(255, 255, 255, 0.03)";
      ctx.lineWidth = 1 / scale;
      const gridSize = 100;
      const aw = area.width || 2e3;
      const ah = area.height || 2e3;
      for (let gx = 0; gx <= aw; gx += gridSize) {
        ctx.beginPath();
        ctx.moveTo(gx, 0);
        ctx.lineTo(gx, ah);
        ctx.stroke();
      }
      for (let gy = 0; gy <= ah; gy += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, gy);
        ctx.lineTo(aw, gy);
        ctx.stroke();
      }
      const ZONE_COLORS = {
        0: "rgba(255,255,255,0.02)",
        1: "rgba(239, 68, 68, 0.25)",
        // Death/Lava
        2: "rgba(56, 189, 248, 0.2)",
        // Ice
        3: "rgba(245, 158, 11, 0.2)",
        // Slow
        4: "rgba(16, 185, 129, 0.22)",
        // Safe Zone
        5: "rgba(168, 85, 247, 0.2)",
        // Gravity
        6: "rgba(251, 146, 60, 0.25)"
        // Boost
      };
      if (Array.isArray(area.zones)) {
        for (const z of area.zones) {
          ctx.fillStyle = ZONE_COLORS[z.type] || "rgba(255,255,255,0.05)";
          ctx.fillRect(z.x, z.y, z.w || z.width || 0, z.h || z.height || 0);
          ctx.strokeStyle = "rgba(255,255,255,0.1)";
          ctx.lineWidth = 1.5 / scale;
          ctx.strokeRect(z.x, z.y, z.w || z.width || 0, z.h || z.height || 0);
        }
      }
      for (const ent of this.specEntities) {
        if (typeof ent.x !== "number" || typeof ent.y !== "number") continue;
        ctx.save();
        ctx.fillStyle = ent.color ? typeof ent.color === "number" ? this.uint32ToColor(ent.color) : ent.color : "#ff3b30";
        ctx.beginPath();
        ctx.arc(ent.x, ent.y, ent.radius || 12, 0, Math.PI * 2);
        ctx.fill();
        if (ent.frozenTimeLeft > 0 || ent.frozen) {
          ctx.strokeStyle = "#00e5ff";
          ctx.lineWidth = 3 / scale;
          ctx.beginPath();
          ctx.arc(ent.x, ent.y, (ent.radius || 12) + 2 / scale, 0, Math.PI * 2);
          ctx.stroke();
        } else if (ent.stompedStunTime > 0 || ent.stunned) {
          ctx.strokeStyle = "#ffdd00";
          ctx.lineWidth = 3 / scale;
          ctx.beginPath();
          ctx.arc(ent.x, ent.y, (ent.radius || 12) + 2 / scale, 0, Math.PI * 2);
          ctx.stroke();
        }
        ctx.restore();
      }
      const trackedEnt = this.specEntities.find((e) => e.radius >= 14 && e.radius <= 18) || { x: targetX, y: targetY };
      if (trackedEnt) {
        ctx.strokeStyle = "#00d4ff";
        ctx.lineWidth = 3 / scale;
        ctx.beginPath();
        ctx.arc(trackedEnt.x, trackedEnt.y, 22, 0, Math.PI * 2);
        ctx.stroke();
        if (this.selectedPlayer) {
          ctx.font = `bold ${Math.max(12, Math.round(14 / scale))}px system-ui, sans-serif`;
          ctx.fillStyle = "#ffffff";
          ctx.textAlign = "center";
          ctx.shadowColor = "rgba(0,0,0,0.8)";
          ctx.shadowBlur = 4;
          ctx.fillText(this.selectedPlayer, trackedEnt.x, trackedEnt.y - 28);
          ctx.shadowBlur = 0;
        }
      }
      ctx.restore();
      ctx.fillStyle = "rgba(0, 0, 0, 0.65)";
      ctx.fillRect(10, 10, 240, 52);
      ctx.strokeStyle = "rgba(16, 185, 129, 0.4)";
      ctx.lineWidth = 1;
      ctx.strokeRect(10, 10, 240, 52);
      ctx.font = "bold 12px system-ui, sans-serif";
      ctx.fillStyle = "#34d399";
      ctx.textAlign = "left";
      ctx.fillText(`\u{1F5FA}\uFE0F ${area.name || "Arena"} (Area ${area.number || 1})`, 18, 28);
      ctx.font = "11px system-ui, sans-serif";
      ctx.fillStyle = "#94a3b8";
      ctx.fillText(`Entities: ${this.specEntities.length} | Latency ~30ms | 60 FPS`, 18, 48);
    }
    // ------------------------------------------------------------------------
    // UI CONSTRUCTION & MOUNTING
    // ------------------------------------------------------------------------
    initUI() {
      this.launcherBtn = document.createElement("div");
      this.launcherBtn.id = "evades-scout-launcher-btn";
      this.launcherBtn.title = "Player Scout & Live Reconstructed Spectator [F7]";
      this.launcherBtn.style.cssText = `
            position: fixed;
            bottom: 10px;
            right: 212px;
            width: 32px;
            height: 32px;
            cursor: pointer;
            z-index: 1000;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(4, 20, 16, 0.85);
            border: 1.5px solid #10b981;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(16, 185, 129, 0.3);
            transition: all 0.2s ease;
        `;
      this.launcherBtn.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#34d399" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="11" cy="11" r="8"></circle>
                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>
        `;
      this.launcherBtn.onmouseover = () => {
        if (this.launcherBtn) {
          this.launcherBtn.style.transform = "scale(1.08)";
          this.launcherBtn.style.boxShadow = "0 0 15px rgba(52, 211, 153, 0.6)";
        }
      };
      this.launcherBtn.onmouseout = () => {
        if (this.launcherBtn) {
          this.launcherBtn.style.transform = "scale(1)";
          this.launcherBtn.style.boxShadow = "0 0 10px rgba(16, 185, 129, 0.3)";
        }
      };
      this.launcherBtn.onclick = () => this.toggleUI();
      this.rootElement = document.createElement("div");
      this.rootElement.id = "evades-scout-modal";
      this.rootElement.style.cssText = `
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 820px;
            max-width: 96vw;
            height: 600px;
            max-height: 92vh;
            background: linear-gradient(145deg, #071a17 0%, #03120f 50%, #041814 100%);
            border: 1.5px solid #10b981;
            border-radius: 16px;
            box-shadow: 0 25px 60px rgba(0,0,0,0.9), 0 0 35px rgba(16, 185, 129, 0.25);
            z-index: 10000006;
            color: #f8fafc;
            font-family: system-ui, -apple-system, sans-serif;
            flex-direction: column;
            overflow: hidden;
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
        `;
      this.rootElement.innerHTML = `
            <!-- Header -->
            <div style="padding: 12px 18px; background: linear-gradient(90deg, rgba(5, 150, 105, 0.6) 0%, rgba(6, 78, 59, 0.4) 100%); border-bottom: 1px solid rgba(16, 185, 129, 0.3); display: flex; align-items: center; justify-content: space-between;">
                <div style="display: flex; align-items: center; gap: 10px;">
                    <span style="font-size: 22px;">\u{1F50D}</span>
                    <div>
                        <div style="font-weight: 800; font-size: 15px; letter-spacing: 0.5px; background: linear-gradient(90deg, #6ee7b7, #34d399, #10b981); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">PLAYER SCOUT & LIVE RECONSTRUCTED SPECTATOR</div>
                        <div style="font-size: 11px; color: #a7f3d0;">Watch any player on any server in real-time without leaving your game session!</div>
                    </div>
                </div>
                <div style="display: flex; align-items: center; gap: 8px;">
                    <button id="scout-btn-refresh" style="background: rgba(16, 185, 129, 0.2); border: 1px solid #10b981; color: #34d399; padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 700; cursor: pointer;">\u{1F504} Refresh</button>
                    <button id="scout-btn-close" style="background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.15); color: #cbd5e1; width: 26px; height: 26px; border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center;">\u2715</button>
                </div>
            </div>

            <!-- Body Grid -->
            <div style="display: flex; flex: 1; overflow: hidden;">
                <!-- Left Pane: Search & Server List -->
                <div style="width: 270px; border-right: 1px solid rgba(255,255,255,0.08); display: flex; flex-direction: column; background: rgba(3, 14, 12, 0.5);">
                    <div style="padding: 10px; border-bottom: 1px solid rgba(255,255,255,0.05);">
                        <input id="scout-search-input" type="text" placeholder="Search online player..." style="width: 100%; box-sizing: border-box; background: #061f1a; border: 1px solid #10b981; border-radius: 8px; padding: 7px 10px; color: #f8fafc; font-size: 12px; outline: none;" />
                    </div>
                    <div id="scout-players-list" style="flex: 1; overflow-y: auto; padding: 6px; display: flex; flex-direction: column; gap: 4px;">
                        <div style="text-align: center; color: #64748b; font-size: 11px; padding: 20px;">Scanning online servers...</div>
                    </div>
                </div>

                <!-- Right Pane: Spectator Canvas & Player Details -->
                <div id="scout-detail-pane" style="flex: 1; display: flex; flex-direction: column; padding: 14px; overflow-y: auto; background: rgba(2, 10, 8, 0.6);">
                    <div style="margin: auto; text-align: center; color: #64748b;">
                        <div style="font-size: 40px; margin-bottom: 8px;">\u{1F464}</div>
                        <div style="font-size: 14px; font-weight: 700; color: #94a3b8;">Select a player to launch reconstructed live stream</div>
                        <div style="font-size: 11px; margin-top: 4px;">Real-time arena reconstruction, enemies, zones & stats</div>
                    </div>
                </div>
            </div>

            <!-- Footer Bar -->
            <div style="padding: 6px 16px; background: rgba(3, 15, 13, 0.9); border-top: 1px solid rgba(255,255,255,0.05); display: flex; justify-content: space-between; align-items: center; font-size: 11px; color: #64748b;">
                <span id="scout-footer-status">Servers: Scanning...</span>
                <span>Toggle hotkey: <b style="color: #34d399;">F7</b></span>
            </div>
        `;
      const closeBtn = this.rootElement.querySelector("#scout-btn-close");
      if (closeBtn) closeBtn.onclick = () => this.toggleUI(false);
      const refreshBtn = this.rootElement.querySelector("#scout-btn-refresh");
      if (refreshBtn) refreshBtn.onclick = () => this.refreshServerList();
      const searchInput = this.rootElement.querySelector("#scout-search-input");
      if (searchInput) {
        searchInput.oninput = (e) => {
          this.searchQuery = e.target.value.toLowerCase().trim();
          this.renderPlayerList();
        };
      }
    }
    mountUI() {
      const attach = () => {
        if (!document.body) return false;
        if (this.launcherBtn && !document.body.contains(this.launcherBtn)) {
          document.body.appendChild(this.launcherBtn);
        }
        if (this.rootElement && !document.body.contains(this.rootElement)) {
          document.body.appendChild(this.rootElement);
        }
        return true;
      };
      if (!attach()) {
        window.addEventListener("DOMContentLoaded", () => attach());
        window.addEventListener("load", () => attach());
        const interval = setInterval(() => {
          if (attach()) clearInterval(interval);
        }, 250);
      }
    }
    bindEvents() {
      window.addEventListener("keydown", (e) => {
        if (e.key === "F7") {
          e.preventDefault();
          this.toggleUI();
        } else if (e.key === "Escape" && this.isVisible) {
          this.toggleUI(false);
        }
      });
    }
    toggleUI(force) {
      this.isVisible = force !== void 0 ? force : !this.isVisible;
      if (this.rootElement) {
        this.rootElement.style.display = this.isVisible ? "flex" : "none";
        if (this.isVisible) {
          this.refreshServerList();
        } else {
          this.stopSpectatorStream();
        }
      }
    }
    async refreshServerList() {
      if (this.isFetching) return;
      this.isFetching = true;
      const footerStatus = this.rootElement ? this.rootElement.querySelector("#scout-footer-status") : null;
      if (footerStatus) footerStatus.innerText = "Refreshing online servers...";
      const servers = await this.fetchGameList();
      this.isFetching = false;
      const totalOnline = servers.reduce((acc, s) => acc + s.connected, 0);
      if (footerStatus) {
        footerStatus.innerHTML = `Online: <b style="color:#34d399;">${totalOnline} players</b> across <b>${servers.length} servers</b>`;
      }
      this.renderPlayerList();
    }
    renderPlayerList() {
      const listEl = this.rootElement ? this.rootElement.querySelector("#scout-players-list") : null;
      if (!listEl) return;
      listEl.innerHTML = "";
      const allPlayers = [];
      for (const s of this.serversData) {
        for (const p of s.online) {
          if (!this.searchQuery || p.toLowerCase().includes(this.searchQuery) || `${s.region} ${s.serverNumber}`.toLowerCase().includes(this.searchQuery)) {
            allPlayers.push({ name: p, server: s });
          }
        }
      }
      if (allPlayers.length === 0) {
        listEl.innerHTML = `<div style="text-align:center; color:#64748b; font-size:11px; padding:20px;">No players found matching "${this.searchQuery}"</div>`;
        return;
      }
      allPlayers.sort((a, b) => a.name.localeCompare(b.name));
      allPlayers.forEach(({ name, server }) => {
        const item = document.createElement("div");
        const isSelected = this.selectedPlayer === name;
        item.style.cssText = `
                padding: 6px 10px;
                border-radius: 8px;
                background: ${isSelected ? "linear-gradient(90deg, rgba(16, 185, 129, 0.25) 0%, rgba(5, 150, 105, 0.15) 100%)" : "rgba(255, 255, 255, 0.03)"};
                border: 1px solid ${isSelected ? "#10b981" : "rgba(255, 255, 255, 0.06)"};
                display: flex;
                align-items: center;
                justify-content: space-between;
                cursor: pointer;
                transition: all 0.15s ease;
            `;
        item.innerHTML = `
                <div style="display: flex; align-items: center; gap: 8px;">
                    <div style="width: 7px; height: 7px; border-radius: 50%; background: #10b981; box-shadow: 0 0 5px #10b981;"></div>
                    <span style="font-weight: 700; font-size: 11.5px; color: ${isSelected ? "#34d399" : "#f1f5f9"};">${name}</span>
                </div>
                <span style="font-size: 9.5px; color: #94a3b8; background: rgba(0,0,0,0.3); padding: 2px 5px; border-radius: 4px;">
                    ${server.region} ${server.serverNumber}
                </span>
            `;
        item.onclick = () => this.selectPlayer(name, server);
        listEl.appendChild(item);
      });
    }
    async selectPlayer(username, server) {
      this.selectedPlayer = username;
      this.selectedPlayerServer = server;
      this.renderPlayerList();
      this.startSpectatorStream(username, server);
      const profile = await this.fetchPlayerProfile(username);
      this.selectedPlayerProfile = profile;
      this.renderSpectateUI();
    }
    renderSpectateUI() {
      const pane = this.rootElement ? this.rootElement.querySelector("#scout-detail-pane") : null;
      if (!pane || !this.selectedPlayer || !this.selectedPlayerServer) return;
      const p = this.selectedPlayer;
      const s = this.selectedPlayerServer;
      const profile = this.selectedPlayerProfile;
      const stats = profile?.stats || {};
      const areas = stats.highest_area_achieved_counter || {};
      pane.innerHTML = `
            <!-- Top Controls & Status Bar -->
            <div style="background: rgba(16, 185, 129, 0.08); border: 1.5px solid rgba(52, 211, 153, 0.3); border-radius: 12px; padding: 12px 16px; margin-bottom: 12px; display: flex; align-items: center; justify-content: space-between;">
                <div>
                    <div style="font-size: 16px; font-weight: 800; color: #f8fafc; display: flex; align-items: center; gap: 8px;">
                        <span>${p}</span>
                        <span style="font-size: 10px; background: rgba(56, 189, 248, 0.2); border: 1px solid #38bdf8; color: #38bdf8; padding: 1px 6px; border-radius: 4px;">${s.region} ${s.serverNumber}</span>
                    </div>
                    <div id="scout-stream-status-text" style="font-size: 11px; color: #34d399; margin-top: 3px; font-weight: 700;">
                        ${this.specStatus}
                    </div>
                </div>
                <div style="display: flex; gap: 8px;">
                    <button id="scout-btn-reconnect" style="background: rgba(16, 185, 129, 0.15); border: 1px solid #10b981; color: #34d399; padding: 6px 12px; border-radius: 8px; font-weight: 700; font-size: 11px; cursor: pointer;">
                        \u{1F504} Reconnect
                    </button>
                    <button id="scout-btn-stop" style="background: rgba(239, 68, 68, 0.15); border: 1px solid #ef4444; color: #f87171; padding: 6px 12px; border-radius: 8px; font-weight: 700; font-size: 11px; cursor: pointer;">
                        \u2715 Stop
                    </button>
                </div>
            </div>

            <!-- Reconstructed Live Canvas Arena -->
            <div style="position: relative; width: 100%; height: 280px; background: #030c0a; border: 1.5px solid rgba(16, 185, 129, 0.4); border-radius: 12px; overflow: hidden; margin-bottom: 12px; box-shadow: 0 8px 25px rgba(0,0,0,0.6);">
                <canvas id="scout-spectate-canvas" style="width: 100%; height: 100%; display: block;"></canvas>
            </div>

            <!-- Regional Highest Records -->
            <div style="background: rgba(3, 15, 13, 0.7); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 12px; padding: 12px; flex: 1;">
                <div style="font-size: 11.5px; font-weight: 800; color: #34d399; text-transform: uppercase; margin-bottom: 8px;">\u{1F3C6} Account Records (Highest Area)</div>
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; max-height: 90px; overflow-y: auto;">
                    ${Object.keys(areas).length > 0 ? Object.keys(areas).map((region) => `
                            <div style="background: rgba(255, 255, 255, 0.03); border: 1px solid rgba(255, 255, 255, 0.05); border-radius: 6px; padding: 4px 8px; display: flex; justify-content: space-between; font-size: 10.5px;">
                                <span style="color: #cbd5e1;">${region}</span>
                                <b style="color: #f59e0b;">Area ${areas[region]}</b>
                            </div>
                        `).join("") : '<div style="color: #64748b; font-size: 11px; grid-column: span 3;">No public run records available for this account.</div>'}
                </div>
            </div>
        `;
      this.specCanvas = pane.querySelector("#scout-spectate-canvas");
      const reconnectBtn = pane.querySelector("#scout-btn-reconnect");
      if (reconnectBtn) reconnectBtn.onclick = () => this.startSpectatorStream(p, s);
      const stopBtn = pane.querySelector("#scout-btn-stop");
      if (stopBtn) stopBtn.onclick = () => this.stopSpectatorStream();
    }
    renderSpectateStatus() {
      const textEl = this.rootElement ? this.rootElement.querySelector("#scout-stream-status-text") : null;
      if (textEl) textEl.innerText = this.specStatus;
    }
  };
  if (typeof window !== "undefined") {
    const w = window;
    if (!w.__evadesPlayerScout) {
      w.__evadesPlayerScout = new PlayerScoutMod();
      w.PlayerScout = w.__evadesPlayerScout;
    }
  }
  var index_default = PlayerScoutMod;
})();
